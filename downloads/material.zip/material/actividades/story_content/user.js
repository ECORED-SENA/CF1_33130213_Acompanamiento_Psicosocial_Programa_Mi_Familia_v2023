function ExecuteScript(strId)
{
  switch (strId)
  {
      case "63E4hPOaC8T":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

